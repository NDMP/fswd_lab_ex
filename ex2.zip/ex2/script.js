fetch("user.json")
  .then(res => res.json())
  .then(data => {
    document.getElementById("loading").style.display = "none";
    document.getElementById("cards").innerHTML = data.map(emp => `
      <div class="card">
        <h3>${emp.Name}</h3>
        <p><b>Office:</b> ${emp.Office}</p>
        <p><b>Position:</b> ${emp.Position}</p>
        <p><b>Salary:</b> ${emp.Salary}</p>
      </div>
    `).join('');
  })
  .catch(() => {
    document.getElementById("cards").innerHTML = "Failed to load employees.";
  });
